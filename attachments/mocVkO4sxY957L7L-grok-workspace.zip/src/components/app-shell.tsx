import type { ReactNode } from "react";
import { Toaster } from "sonner";

import { Navbar } from "@/components/navbar";
import { ProfileProvider } from "@/components/profile";
import { SupportPill } from "@/components/support-pill";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <ProfileProvider>
      <div className="relative min-h-screen bg-ink text-fg">
        <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,rgba(124,58,237,0.28),transparent_55%)]" />
        <div className="relative">
          <Navbar />
          {children}
        </div>
        <SupportPill />
        <Toaster theme="dark" />
      </div>
    </ProfileProvider>
  );
}
