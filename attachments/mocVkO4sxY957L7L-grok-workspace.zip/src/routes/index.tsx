import { createFileRoute, Link } from "@tanstack/react-router";

import { useProfileState } from "@/components/profile";
import { RoleBadge } from "@/components/role-badge";
import { formatUsd } from "@/lib/money";

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>) => ({
    browse: search.browse === true || search.browse === "true" ? (true as const) : undefined,
  }),
  component: Home,
});

function Home() {
  const { profile, ready } = useProfileState();
  return (
    <main className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-3xl flex-col items-center justify-center px-4 py-16 text-center">
      <p className="text-xs font-semibold tracking-[0.22em] text-violet uppercase">Game top-up</p>
      <h1 className="mt-3 font-display text-4xl font-extrabold tracking-tight sm:text-6xl">
        <span className="text-gradient">NovaCharge</span>
      </h1>
      <p className="mt-4 max-w-xl text-muted">
        Sign in to see your wallet, role, and the catalog. Registration is instant — no email confirmation.
      </p>
      {profile ? (
        <div className="glass mt-8 flex flex-wrap items-center justify-center gap-3 rounded-3xl px-5 py-4">
          <RoleBadge role={profile.role} />
          <span className="font-semibold tabular-nums">{formatUsd(profile.balanceCents)}</span>
          <span className="text-sm text-muted">@{profile.username}</span>
        </div>
      ) : ready ? (
        <Link
          to="/login"
          search={{ tab: undefined }}
          className="btn-glow mt-8 inline-flex min-h-11 items-center rounded-full px-6 text-sm font-semibold"
        >
          Sign in
        </Link>
      ) : (
        <div className="mt-8 h-11 w-36 animate-pulse rounded-full bg-white/10" />
      )}
    </main>
  );
}
