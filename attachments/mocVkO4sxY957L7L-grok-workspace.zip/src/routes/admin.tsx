import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin · NovaCharge" }] }),
  component: () => (
    <main className="mx-auto max-w-xl px-4 py-16 text-center">
      <h1 className="font-display text-3xl font-extrabold">Admin Panel</h1>
      <p className="mt-3 text-muted">Sessions, income, and user balances land on this screen with the dashboard.</p>
      <Link to="/" search={{ browse: true }} className="mt-6 inline-flex min-h-11 items-center text-sm font-semibold text-fuchsia">
        Back to NovaCharge
      </Link>
    </main>
  ),
});
