import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/orders")({
  head: () => ({ meta: [{ title: "My Orders · NovaCharge" }] }),
  component: () => (
    <main className="mx-auto max-w-xl px-4 py-16 text-center">
      <h1 className="font-display text-3xl font-extrabold">My Orders</h1>
      <p className="mt-3 text-muted">Your purchase history shows up here once the storefront checkout is connected.</p>
      <Link to="/" search={{ browse: true }} className="mt-6 inline-flex min-h-11 items-center text-sm font-semibold text-violet">
        Back to NovaCharge
      </Link>
    </main>
  ),
});
