import { createFileRoute, Link } from "@tanstack/react-router";

import { categoryLabel } from "@/lib/store/types";

export const Route = createFileRoute("/category/$slug")({
  component: CategoryPage,
});

function CategoryPage() {
  const { slug } = Route.useParams();
  return (
    <main className="mx-auto max-w-xl px-4 py-16 text-center">
      <p className="text-xs font-semibold tracking-[0.18em] text-violet uppercase">Category</p>
      <h1 className="mt-2 font-display text-3xl font-extrabold">{categoryLabel(slug)}</h1>
      <p className="mt-3 text-muted">Packages in this lane open with the storefront.</p>
      <Link to="/" search={{ browse: true }} className="mt-6 inline-flex min-h-11 items-center text-sm font-semibold text-violet">
        All services
      </Link>
    </main>
  );
}
